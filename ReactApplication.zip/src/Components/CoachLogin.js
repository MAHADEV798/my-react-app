import "bootstrap/dist/css/bootstrap.min.css";
import { useRef } from "react";

function CoachLogin()
{
    let uname=useRef('');
    let pword=useRef('');
    
    return(
        <>
<div className="row">
    <div className="col-sm-2">
    </div>
    <div className="col-sm-8">
    <div className="row">
        <div>
        <h1>Login as Life coach</h1>
        </div>
        <form>
            <input className="form-control" type="text" placeholder="Coach Id"></input><br></br>
            <input className="form-control" type="text" placeholder="Password"></input><br></br>
            <button className="btn btn-success">Login</button>
        </form>
        
    </div>
    </div>
    <div className="col-sm-2">
    </div>
</div>
</>
)
}

export default CoachLogin;