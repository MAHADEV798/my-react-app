import "bootstrap/dist/css/bootstrap.min.css";
import { Navigate } from "react-router-dom";
import CoachLogin from './CoachLogin.js';
import { useNavigate } from "react-router-dom";
function Home()
{
    let navigate = useNavigate();
    function CoachLogin1()
    {
        navigate('/CoachLogin');
    }
    return(
        <>
<div className="row">
    <div className="col-sm-2">
    </div>
    <div className="col-sm-8">
    <div className="row">
        <div>
        <h1>We are at the heart of the appropriate care</h1>
        </div>
        <div className="col-sm-6 d-flex justify-content-center">
        <div className="card" style={{width:"240px"}}>
            <img className="card-img-top mx-auto d-block" src="./coach.jpg" alt="coach" style={{width:"100px",height:"145px"}}/>
            <div className="card-body">
            <button className="btn btn-success" onClick={CoachLogin1}>Login as a Coach</button>
            </div>
        </div>
        </div>
        <div className="col-sm-6 d-flex justify-content-center">
        <div className="card" style={{width:"240px"}}>
            <img className="card-img-top mx-auto d-block" src="./coach.jpg" alt="coach" style={{width:"100px",height:"145px"}}/>
            <div className="card-body">
                <button className="btn btn-success">Login as a User</button>
            </div>
        </div>
        </div>
    </div>
    </div>
    <div className="col-sm-2">
    </div>
</div>
</>
)
}

export default Home;